﻿using Hackathon_WebAPI.Controllers;
using Hackathon_WebAPI.Model;
using Hackathon_WebAPI.Repositories;
using Hackathon_WebAPI.Services;
using Hackathon_WebAPI_Tests.Repositories;
using Hackathon_WebAPI_Tests.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace Hackathon_WebAPI_Tests
{
    public class ShoppingCartControllerWithRepoTest
    {
        ShoppingCartController _controller;
        IShoppingCartService _service;
        IShoppingCartItemRepository _shoppingCartItemRepository;

        public ShoppingCartControllerWithRepoTest()
        {
            _shoppingCartItemRepository = new ShoppingCartItemRepositoryMock();
            _service = new ShoppingCartServiceWithRepositoryMock(_shoppingCartItemRepository);
            _controller = new ShoppingCartController(_service);
        }

        //Testing Get Method
        [Fact]
        public void Get_WhenCalled_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.Get();

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void Get_WhenCalled_ReturnsAllItems()
        {
            // Act
            var okResult = _controller.Get().Result as OkObjectResult;

            // Assert
            var items = Assert.IsType<List<ShoppingItem>>(okResult.Value);
            Assert.Equal(3, items.Count);
        }

        //Testing GetById Method
        [Fact]
        public void GetById_UnknownGuidPassed_ReturnsNotFoundResult()
        {
            // Act
            var notFoundResult = _controller.Get(Guid.NewGuid());

            // Assert
            Assert.IsType<NotFoundResult>(notFoundResult.Result);
        }

        [Fact]
        public void GetById_ExistingGuidPassed_ReturnsOkResult()
        {
            // Arrange
            var testGuid = new Guid("ab2bd817-98cd-4cf3-a80a-53ea0cd9c200");

            // Act
            var okResult = _controller.Get(testGuid);

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void GetById_ExistingGuidPassed_ReturnsRightItem()
        {
            // Arrange
            var testGuid = new Guid("ab2bd817-98cd-4cf3-a80a-53ea0cd9c200");

            // Act
            var okResult = _controller.Get(testGuid).Result as OkObjectResult;

            // Assert
            Assert.IsType<ShoppingItem>(okResult.Value);
            Assert.Equal(testGuid, (okResult.Value as ShoppingItem).Id);
        }

        //Testing Add Method
        [Fact]
        public void Add_InvalidObjectPassed_ReturnsBadRequest()
        {
            // Arrange
            var nameMissingItem = new ShoppingItem()
            {
                Manufacturer = "OnePlus",
                Price = 40000.00M,
                Quantity = 1
            };
            _controller.ModelState.AddModelError("Name", "Required");

            // Act
            var badResponse = _controller.Post(nameMissingItem);

            // Assert
            Assert.IsType<BadRequestObjectResult>(badResponse);
        }


        [Fact]
        public void Add_ValidObjectPassed_ReturnsCreatedResponse()
        {
            // Arrange
            ShoppingItem testItem = new ShoppingItem()
            {
                Name = "OnePlus 7T",
                Manufacturer = "OnePlus",
                Price = 40000.00M,
                Quantity = 1
            };

            // Act
            var createdResponse = _controller.Post(testItem);

            // Assert
            Assert.IsType<CreatedAtActionResult>(createdResponse);
        }


        [Fact]
        public void Add_ValidObjectPassed_ReturnedResponseHasCreatedItem()
        {
            // Arrange
            var testItem = new ShoppingItem()
            {
                Name = "OnePlus 7T",
                Manufacturer = "OnePlus",
                Price = 40000.00M,
                Quantity = 1
            };

            // Act
            var createdResponse = _controller.Post(testItem) as CreatedAtActionResult;
            var item = createdResponse.Value as ShoppingItem;

            // Assert
            Assert.IsType<ShoppingItem>(item);
            Assert.Equal("OnePlus 7T", item.Name);
        }


        //Testing Remove Method

        [Fact]
        public void Remove_NotExistingGuidPassed_ReturnsNotFoundResponse()
        {
            // Arrange
            var notExistingGuid = Guid.NewGuid();

            // Act
            var badResponse = _controller.Remove(notExistingGuid);

            // Assert
            Assert.IsType<NotFoundResult>(badResponse);
        }

        [Fact]
        public void Remove_ExistingGuidPassed_ReturnsOkResult()
        {
            // Arrange
            var existingGuid = new Guid("ab2bd817-98cd-4cf3-a80a-53ea0cd9c200");

            // Act
            var okResponse = _controller.Remove(existingGuid);

            // Assert
            Assert.IsType<OkResult>(okResponse);
        }
        [Fact]
        public void Remove_ExistingGuidPassed_RemovesOneItem()
        {
            // Arrange
            var existingGuid = new Guid("ab2bd817-98cd-4cf3-a80a-53ea0cd9c200");

            // Act
            var okResponse = _controller.Remove(existingGuid);

            // Assert
            Assert.Equal(2, _service.GetAllItems().Count());
        }

        //Testing Update Method
        [Fact]
        public void Update_NotExistingGuidPassed_ReturnsNotFoundResponse()
        {
            // Arrange
            var notExistingGuid = Guid.NewGuid();

            // Act
            var badResponse = _controller.Update(notExistingGuid, 2);

            // Assert
            Assert.IsType<NotFoundResult>(badResponse);
        }
        [Fact]
        public void Update_ExistingGuidPassed_ReturnsOkResult()
        {
            // Arrange
            var existingGuid = new Guid("815accac-fd5b-478a-a9d6-f171a2f6ae7f");

            // Act
            var okResponse = _controller.Update(existingGuid, 2);

            // Act
            var createdResponse = _controller.Update(existingGuid, 2);

            // Assert
            Assert.IsType<CreatedAtActionResult>(createdResponse);
        }

        [Fact]
        public void Update_ExistingGuidPassed_UpdatedQuantity()
        {
            // Arrange
            var existingGuid = new Guid("815accac-fd5b-478a-a9d6-f171a2f6ae7f");

            // Act
            var okResponse = _controller.Update(existingGuid, 2);

            // Act
            var createdResponse = _controller.Update(existingGuid, 2) as CreatedAtActionResult;
            var item = createdResponse.Value as ShoppingItem;

            // Assert
            Assert.IsType<ShoppingItem>(item);
            Assert.Equal(2, item.Quantity);
        }
    }
}
