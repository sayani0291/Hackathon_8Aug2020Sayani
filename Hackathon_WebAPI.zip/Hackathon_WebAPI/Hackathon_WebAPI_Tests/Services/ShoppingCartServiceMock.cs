﻿using Hackathon_WebAPI.Model;
using Hackathon_WebAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hackathon_WebAPI_Tests.Services
{
    public class ShoppingCartServiceMock : IShoppingCartService
    {
        private readonly List<ShoppingItem> _shoppingCart;

        public ShoppingCartServiceMock()
        {
            _shoppingCart = new List<ShoppingItem>()
            {
                new ShoppingItem() { Id = new Guid("ab2bd817-98cd-4cf3-a80a-53ea0cd9c200"),
                    Name = "Samsung S10", Manufacturer="Samsung", Price = 40000.00M, Quantity=1 },
                new ShoppingItem() { Id = new Guid("815accac-fd5b-478a-a9d6-f171a2f6ae7f"),
                    Name = "iPhone11", Manufacturer="Apple", Price = 60000.00M, Quantity=1 },
                new ShoppingItem() { Id = new Guid("33704c4a-5b87-464c-bfb6-51971b4d18ad"),
                    Name = "Airpod", Manufacturer="Apple", Price = 14000.00M, Quantity=1 }
            };
        }

        public IEnumerable<ShoppingItem> GetAllItems()
        {
            return _shoppingCart;
        }

        public ShoppingItem Add(ShoppingItem newItem)
        {
            newItem.Id = Guid.NewGuid();
            _shoppingCart.Add(newItem);
            return newItem;
        }

        public ShoppingItem GetById(Guid id)
        {
            return _shoppingCart.Where(a => a.Id == id)
                .FirstOrDefault();
        }

        public void Remove(Guid id)
        {
            var existing = _shoppingCart.First(a => a.Id == id);
            _shoppingCart.Remove(existing);
        }

        public ShoppingItem Update(Guid id,int quantity)
        {
            var existing = _shoppingCart.First(a => a.Id == id);
            existing.Quantity = quantity;
            return existing;
        }
    }
}
