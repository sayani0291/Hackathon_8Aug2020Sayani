﻿using Hackathon_WebAPI.Model;
using Hackathon_WebAPI.Repositories;
using Hackathon_WebAPI.Services;
using Hackathon_WebAPI_Tests.Repositories;
using Microsoft.VisualStudio.TestPlatform.Common.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hackathon_WebAPI_Tests.Services
{
    public class ShoppingCartServiceWithRepositoryMock : IShoppingCartService
    {
        private readonly IShoppingCartItemRepository _shoppingCartItemRepository;

        public ShoppingCartServiceWithRepositoryMock(IShoppingCartItemRepository shoppingCartItemRepository)
        {
            _shoppingCartItemRepository = shoppingCartItemRepository;
        }
        public ShoppingItem Add(ShoppingItem newItem)
        {
            return _shoppingCartItemRepository.Add(newItem);
        }

        public IEnumerable<ShoppingItem> GetAllItems()
        {
            return _shoppingCartItemRepository.GetAllItems();
        }

        public ShoppingItem GetById(Guid id)
        {
            return _shoppingCartItemRepository.GetById(id);
        }

        public void Remove(Guid id)
        {
             _shoppingCartItemRepository.Remove(id);
        }

        public ShoppingItem Update(Guid id, int quantity)
        {
            return _shoppingCartItemRepository.Update(id,quantity);
        }
    }
}
