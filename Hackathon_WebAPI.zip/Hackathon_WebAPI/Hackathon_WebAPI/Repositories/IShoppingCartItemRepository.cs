﻿using Hackathon_WebAPI.Model;
using System;
using System.Collections.Generic;

namespace Hackathon_WebAPI.Repositories
{
    public interface IShoppingCartItemRepository
    {
        ShoppingItem Add(ShoppingItem newItem);
        IEnumerable<ShoppingItem> GetAllItems();
        ShoppingItem GetById(Guid id);
        void Remove(Guid id);
        ShoppingItem Update(Guid id, int quantity);
    }
}