﻿using Hackathon_WebAPI.Model;
using System;

namespace Hackathon_WebAPI.Services
{
    public interface IShoppingCartService
    {
        ShoppingItem Add(ShoppingItem newItem);
        System.Collections.Generic.IEnumerable<ShoppingItem> GetAllItems();
        ShoppingItem GetById(Guid id);
        void Remove(Guid id);
        ShoppingItem Update(Guid id, int quantity);
    }
}