﻿using System;
using System.Collections.Generic;
using Hackathon_WebAPI.Model;
using Hackathon_WebAPI.Repositories;

namespace Hackathon_WebAPI.Services
{
    public class ShoppingCartService : IShoppingCartService
    {
        private readonly IShoppingCartItemRepository _shoppingCartItemRepository;
        public ShoppingCartService(IShoppingCartItemRepository shoppingCartItemRepository)
        {
            _shoppingCartItemRepository = shoppingCartItemRepository;
        }
        public ShoppingItem Add(ShoppingItem newItem)
        {
            return _shoppingCartItemRepository.Add(newItem);
        }

        public IEnumerable<ShoppingItem> GetAllItems()
        {
            return _shoppingCartItemRepository.GetAllItems();
        }

        public ShoppingItem GetById(Guid id)
        {
            return _shoppingCartItemRepository.GetById(id);
        }

        public void Remove(Guid id)
        {
             _shoppingCartItemRepository.Remove(id);
        }

        public ShoppingItem Update(Guid id, int quantity)
        {
            return _shoppingCartItemRepository.Update(id,quantity);
        }
    }
}
